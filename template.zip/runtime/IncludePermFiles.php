<?php

	// array('DROPIN'=>DATABASEID, ...);
	self::$includePermFiles = array('setNgxMaterial/dibAdmin'=>1);