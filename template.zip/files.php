<?php
$DIR = __DIR__;
include_once("./vendor/dropinbase/dropinbase/files.php");