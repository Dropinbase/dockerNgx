<?php

//phpinfo(); die(); // To view installed PHP extensions, uncomment this line

$DIR = __DIR__;

// Run Dropinbase
include_once("./vendor/dropinbase/dropinbase/index.php"); die();

// Run Installer
//include_once("./installer.php");