<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>

<body>
<h1>Dropinbase Client</h1>

These files are dependant on the <a href="https://github.com/Dropinbase/framework">Dropinbase framework</a>.<br><br>

Dropinbase enables rapid prototyping, development and maintenance of database/business applications, without limiting customizations.<br> 
Extensions are easy to add, and can be shared with other community members.<br><br>

<b>Home: </b>http://www.dropinbase.com <br>

</body>
</html>

